package com.ecommerce.controller;

import com.ecommerce.model.User;

import java.util.HashMap;
import java.util.Map;

public class UserController {
    private Map<String, User> users = new HashMap<>();

    public boolean register(String username, String password) {
        if (users.containsKey(username)) {
            System.out.println("Username already exists. Please choose another.");
            return false;
        }
        users.put(username, new User(username, password));
        System.out.println("User  registered successfully.");
        return true;
    }

    public boolean signIn(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password)) {
            System.out.println("Sign-in successful.");
            return true;
        }
        System.out.println("Invalid username or password.");
        return false;
    }
}
