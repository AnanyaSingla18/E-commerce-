package com.ecommerce.controller;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.Order;

import java.util.List;
import java.util.PriorityQueue;

public class OrderController {
    private PriorityQueue<Order> orderQueue = new PriorityQueue<>();

    public void placeOrder(List<CartItem> items, boolean express) {
        if (items.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }
        Order order = new Order(items, express);
        orderQueue.offer(order);
        System.out.println("Order placed successfully (" + (express ? "Express" : "Normal") + ")");
    }

    public void processOrders() {
        if (orderQueue.isEmpty()) {
            System.out.println("No orders to process.");
            return;
        }

        System.out.println("Processing orders:");
        while (!orderQueue.isEmpty()) {
            Order order = orderQueue.poll();
            System.out.println(order);
        }
    }
}
