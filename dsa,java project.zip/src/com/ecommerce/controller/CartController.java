package com.ecommerce.controller;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.Product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartController {
    private Map<Integer, CartItem> cart = new HashMap<>();

    public void addToCart(Product product, int quantity) {
        if (cart.containsKey(product.getId())) {
            CartItem existing = cart.get(product.getId());
            cart.put(product.getId(), new CartItem(product, existing.getQuantity() + quantity));
        } else {
            cart.put(product.getId(), new CartItem(product, quantity));
        }
        System.out.println(product.getName() + " added to cart.");
    }

    public void viewCart() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty.");
            return;
        }

        System.out.println("Your cart:");
        for (CartItem item : cart.values()) {
            System.out.println(item);
        }
    }

    public List<CartItem> getCartItems() {
        return new ArrayList<>(cart.values());
    }

    public void clearCart() {
        cart.clear();
    }
}
