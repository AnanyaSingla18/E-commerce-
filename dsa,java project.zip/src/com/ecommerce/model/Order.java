package com.ecommerce.model;

import java.util.List;

public class Order implements Comparable<Order> {
    private List<CartItem> items;
    private boolean express;

    public Order(List<CartItem> items, boolean express) {
        this.items = items;
        this.express = express;
    }

    public List<CartItem> getItems() { return items; }
    public boolean isExpress() { return express; }

    @Override
    public int compareTo(Order o) {
        return Boolean.compare(o.express, this.express); // express > normal
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Order (" + (express ? "Express" : "Normal") + "):\n");
        for (CartItem item : items) {
            sb.append(" - ").append(item.toString()).append("\n");
        }
        return sb.toString();
    }
}
