package com.ecommerce.model;

public class Product {
    private int id;
    private String name;
    private double price;
    private int popularity;
    private String category; // New field for category

    public Product(int id, String name, double price, int popularity, String category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.popularity = popularity;
        this.category = category; // Initialize category
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getPopularity() { return popularity; }
    public String getCategory() { return category; } // Getter for category

    @Override
    public String toString() {
        return id + ": " + name + " | $" + price + " | Popularity: " + popularity + " | Category: " + category;
    }
}
