package com.ecommerce;

import com.ecommerce.controller.CartController;
import com.ecommerce.controller.OrderController;
import com.ecommerce.controller.ProductController;
import com.ecommerce.controller.UserController;
import com.ecommerce.model.CartItem;
import com.ecommerce.model.Product;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ProductController productController = new ProductController();
        CartController cartController = new CartController();
        OrderController orderController = new OrderController();
        UserController userController = new UserController();

        Map<String, String> registeredUsers = new HashMap<>();
        registeredUsers.put("Ananya", "ananya");
        registeredUsers.put("user2", "password2");
        registeredUsers.put("user3", "password3");

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        // Add demo products with categories and INR prices (as double)
        productController.addProduct(new Product(1, "Samsung Phone", 59999.00, 80, "Electronics"));
        productController.addProduct(new Product(2, "Apple Laptop", 99999.00, 70, "Electronics"));
        productController.addProduct(new Product(3, "Sony Headphones", 19999.00, 90, "Electronics"));
        productController.addProduct(new Product(4, "OnePlus Phone", 49999.00, 85, "Electronics"));
        productController.addProduct(new Product(5, "Dell Laptop", 89999.00, 75, "Electronics"));
        productController.addProduct(new Product(6, "JBL Headphones", 14999.00, 80, "Electronics"));
        productController.addProduct(new Product(7, "HP Laptop", 79999.00, 70, "Electronics"));
        productController.addProduct(new Product(8, "Boat Headphones", 9999.00, 85, "Electronics"));
        productController.addProduct(new Product(9, "Lenovo Laptop", 69999.00, 75, "Electronics"));
        productController.addProduct(new Product(10, "Realme Phone", 39999.00, 80, "Electronics"));

        productController.addProduct(new Product(11, "Nike Shoes", 4999.00, 80, "Clothing"));
        productController.addProduct(new Product(12, "Adidas T-Shirt", 1999.00, 70, "Clothing"));
        productController.addProduct(new Product(13, "Puma Jacket", 2999.00, 85, "Clothing"));
        productController.addProduct(new Product(14, "Levis Jeans", 3999.00, 75, "Clothing"));
        productController.addProduct(new Product(15, "Raymond Shirt", 2999.00, 80, "Clothing"));
        productController.addProduct(new Product(16, "Wrangler Jeans", 3499.00, 70, "Clothing"));
        productController.addProduct(new Product(17, "USPA T-Shirt", 1999.00, 85, "Clothing"));
        productController.addProduct(new Product(18, "Pepe Jeans", 3999.00, 75, "Clothing"));
        productController.addProduct(new Product(19, "Flying Machine T-Shirt", 2499.00, 80, "Clothing"));
        productController.addProduct(new Product(20, "Arrow Shirt", 2999.00, 70, "Clothing"));

        productController.addProduct(new Product(21, "Titan Watch", 4999.00, 80, "Accessories"));
        productController.addProduct(new Product(22, "Fastrack Sunglasses", 1999.00, 70, "Accessories"));
        productController.addProduct(new Product(23, "Ray-Ban Sunglasses", 2999.00, 85, "Accessories"));
        productController.addProduct(new Product(24, "Oakley Sunglasses", 3999.00, 75, "Accessories"));
        productController.addProduct(new Product(25, "Tag Heuer Watch", 29999.00, 80, "Accessories"));
        productController.addProduct(new Product(26, "Fossil Watch", 19999.00, 70, "Accessories"));
        productController.addProduct(new Product(27, "Skagen Watch", 14999.00, 85, "Accessories"));
        productController.addProduct(new Product(28, "Daniel Wellington Watch", 9999.00, 75, "Accessories"));
        productController.addProduct(new Product(29, "Tommy Hilfiger Watch", 12999.00, 80, "Accessories"));
        productController.addProduct(new Product(30, "Michael Kors Watch", 15999.00, 70, "Accessories"));

        boolean loggedIn = false;
        String currentUser = null;

        while (running) {
            if (!loggedIn) {
                System.out.println("\n--- User Authentication ---");
                System.out.println("1. Register");
                System.out.println("2. Sign In");
                int authChoice = readInt(scanner, "Enter your choice: ");
                scanner.nextLine();

                if (authChoice == 1) {
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    if (registeredUsers.containsKey(username)) {
                        System.out.println("Username already exists. Please sign in.");
                    } else {
                        registeredUsers.put(username, password);
                        System.out.println("User registered successfully.");
                        loggedIn = true;
                        currentUser = username;
                    }
                } else if (authChoice == 2) {
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    if (registeredUsers.containsKey(username) && registeredUsers.get(username).equals(password)) {
                        System.out.println("Sign-in successful.");
                        loggedIn = true;
                        currentUser = username;
                    } else {
                        System.out.println("Invalid username or password.");
                    }
                } else {
                    System.out.println("Invalid choice!");
                }
                continue;
            }

            System.out.println("\n--- E-Commerce Console ---");
            System.out.println("1. View Products by Category");
            System.out.println("2. Search Product");
            System.out.println("3. Sort Products by Price");
            System.out.println("4. Sort Products by Popularity");
            System.out.println("5. Add to Cart");
            System.out.println("6. View Cart");
            System.out.println("7. Place Order (Express/Normal)");
            System.out.println("8. Process Orders");
            System.out.println("9. Logout");
            System.out.println("0. Exit");

            int choice = readInt(scanner, "Enter your choice: ");
            scanner.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.println("Categories:");
                    System.out.println("1. Electronics");
                    System.out.println("2. Clothing");
                    System.out.println("3. Accessories");
                    int catChoice = readInt(scanner, "Select category: ");
                    scanner.nextLine();
                    String category = switch (catChoice) {
                        case 1 -> "Electronics";
                        case 2 -> "Clothing";
                        case 3 -> "Accessories";
                        default -> "";
                    };
                    if (!category.isEmpty()) {
                        List<Product> products = productController.getAllProducts().stream()
                                .filter(p -> p.getCategory().equalsIgnoreCase(category))
                                .toList();
                        if (products.isEmpty()) {
                            System.out.println("No products found in this category.");
                        } else {
                            System.out.println("=== " + category.toUpperCase() + " ===");
                            for (Product p : products) {
                                System.out.printf("%d: %s | ₹%,.2f | Popularity: %d%n", p.getId(), p.getName(), p.getPrice(), p.getPopularity());
                            }
                        }
                    } else {
                        System.out.println("Invalid category!");
                    }
                }
                case 2 -> {
                    System.out.print("Enter product name to search: ");
                    String name = scanner.nextLine();
                    List<Product> result = productController.searchProduct(name);
                    if (result.isEmpty()) {
                        System.out.println("No products found matching your search.");
                    } else {
                        System.out.println("=== Search Results ===");
                        for (Product p : result) {
                            System.out.printf("%d: %s | ₹%,.2f | Category: %s | Popularity: %d%n", p.getId(), p.getName(), p.getPrice(), p.getCategory(), p.getPopularity());
                        }
                    }
                }
                case 3 -> {
                    System.out.println("=== Products Sorted by Price ===");
                    for (Product p : productController.sortByPrice()) {
                        System.out.printf("%d: %s | ₹%,.2f | Category: %s | Popularity: %d%n", p.getId(), p.getName(), p.getPrice(), p.getCategory(), p.getPopularity());
                    }
                }
                case 4 -> {
                    System.out.println("=== Products Sorted by Popularity ===");
                    for (Product p : productController.sortByPopularity()) {
                        System.out.printf("%d: %s | ₹%,.2f | Category: %s | Popularity: %d%n", p.getId(), p.getName(), p.getPrice(), p.getCategory(), p.getPopularity());
                    }
                }
                case 5 -> {
                    int id = readInt(scanner, "Enter Product ID: ");
                    int qty = readInt(scanner, "Enter Quantity: ");
                    scanner.nextLine();
                    Product product = productController.getProductById(id);
                    if (product != null) {
                        cartController.addToCart(product, qty);
                    } else {
                        System.out.println("Product not found.");
                    }
                }
                case 6 -> {
                    List<CartItem> items = cartController.getCartItems();
                    if (items.isEmpty()) {
                        System.out.println("Your cart is empty.");
                    } else {
                        System.out.println("=== Your Cart ===");
                        double totalPrice = 0.0;
                        for (CartItem item : items) {
                            Product p = item.getProduct();
                            int quantity = item.getQuantity();
                            double itemTotal = quantity * p.getPrice();
                            totalPrice += itemTotal;
                            System.out.printf("%d: %s | ₹%,.2f x %d = ₹%,.2f%n", p.getId(), p.getName(), p.getPrice(), quantity, itemTotal);
                        }
                        System.out.println("------------------------------");
                        System.out.printf("Total Price: ₹%,.2f%n", totalPrice);
                    }
                }
                case 7 -> {
                    System.out.print("Express delivery? (yes/no): ");
                    String type = scanner.nextLine();
                    boolean isExpress = type.equalsIgnoreCase("yes");
                    List<CartItem> items = cartController.getCartItems();
                    if (items.isEmpty()) {
                        System.out.println("Your cart is empty. Please add products before placing an order.");
                    } else {
                        orderController.placeOrder(items, isExpress);
                        cartController.clearCart();
                    }
                }
                case 8 -> orderController.processOrders();
                case 9 -> {
                    loggedIn = false;
                    currentUser = null;
                    System.out.println("Logged out successfully.");
                }
                case 0 -> {
                    running = false;
                    System.out.println("Thank you for shopping with us! We hope to see you again soon! 😊");
                }
                default -> System.out.println("Invalid choice!");
            }
        }
        scanner.close();
    }

    private static int readInt(Scanner scanner, String prompt) {
        int number;
        while (true) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                number = scanner.nextInt();
                scanner.nextLine(); // consume newline
                return number;
            } else {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine();
            }
        }
    }
}
